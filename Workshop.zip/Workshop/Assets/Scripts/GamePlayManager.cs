﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GamePlayManager : MonoBehaviour
{
    private static GamePlayManager sGlobalRef;
    public AudioSource mTapSFX;
    public Sprite[] mFishSprites;
    public Transform[] mSpawnPositions;
    public GameObject mFishPrefab;
    private float mScore = 0;
    public Text mScoreText;
    public GameObject mLevelFail;

    // Use this for initialization
    void Awake()
    {
        if (sGlobalRef == null)
        {
            sGlobalRef = this;
        }
    }
    void Start()
    {
        mScore = 0;
        mLevelFail.gameObject.SetActive(false);
        CancelInvoke("GenerateFish");

       
        InvokeRepeating("GenerateFish", 0, 2f);
        UpdateScoreText();

    }

    public static GamePlayManager SharedInstance()
    {
        GamePlayManager retVal = null;
        if (sGlobalRef != null)
        {
            retVal = sGlobalRef;
        }
        return sGlobalRef;
    }
    // Update is called once per frame
    public void OnFishTap()
    {
        mScore = mScore + 5;
        UpdateScoreText();
        mTapSFX.Play();
    }
    void UpdateScoreText()
    {
        mScoreText.text = mScore.ToString();

    }
    public void OnFishMovedOutOfScreen()
    {
        OnLevelFailed();

    }
    public void OnLevelFailed()
    {
        CancelInvoke("GenerateFish");
        mLevelFail.gameObject.SetActive(true);

    }
    public void OnPlayButtonClick()
    {
        mLevelFail.gameObject.SetActive(false);
        Start();
    }

    void GenerateFish()
    {
        GameObject fish = Instantiate(mFishPrefab);
        int randomSpriteIndex = UnityEngine.Random.Range(0, mFishSprites.Length);
        fish.GetComponent<SpriteRenderer>().sprite = mFishSprites[randomSpriteIndex];
        int randomSpawnIndex = UnityEngine.Random.Range(0, mFishSprites.Length);
        fish.GetComponent<Transform>().position = mSpawnPositions[randomSpawnIndex].position;

    }
}
