﻿
using UnityEngine;
using System.Collections;
public class Fishscript : MonoBehaviour
{
    public ParticleSystem mHitEffect;
    private Vector3 mMoveOffset = new Vector3(0.1f, 0, 0);
    private float mSpeed = 1f;


    // Use this for initialization
    void Start()
    {
        mSpeed = UnityEngine.Random.Range(30f, 60f);

    }

    // Update is called once per frame
    void Update()
    {
        transform.position = transform.position + (mMoveOffset * Time.deltaTime * mSpeed);

    }
    void OnMouseDown()
    {
        GamePlayManager.SharedInstance().OnFishTap();
        Debug.Log("User Tapped on Fish");
        mHitEffect.Play();
        Invoke("HideFish", 0.3f); 
        
    }
    void OnBecameInvisible()
    {
        if (gameObject.activeSelf)
        {
            Debug.Log("Fish Moved out of screen");
            GamePlayManager.SharedInstance().OnFishMovedOutOfScreen();

        }
        Destroy(gameObject);
    }
    void HideFish()
    {
        gameObject.SetActive(false);

    }
}